/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stream;

/**
 *
 * @author Anonymous
 */

import java.io.*;

public class gabungfile {
    public static void main(String [] args)throws IOException{
        FileInputStream an=null;//membaca dari file
        FileInputStream lu=null;
        BufferedReader br=null;//input karakter
        BufferedReader brd=null;
        DataInputStream d=null;//membaca input
        DataInputStream c=null;
        String data=null;
        FileWriter fw=null; //menuliskan output
        BufferedWriter out=null;//output karakter stream
        try{
            an = new FileInputStream("D:\\Java\\copy.txt");
            lu=new FileInputStream("D:\\Java\\paste.txt");
            d=new DataInputStream(an);
            c=new DataInputStream(lu);
            br=new BufferedReader(new InputStreamReader(d));
            brd=new BufferedReader(new InputStreamReader(c));
            data=br.readLine()+"\n"+brd.readLine();
            fw=new FileWriter("D:\\Java\\tambahfile.txt");
            out=new BufferedWriter(fw);
            out.write(data);
            out.close();
            System.out.println("Berhasil Menggabungkan File");

        }catch(FileNotFoundException e){
            System.out.println("Gagal Menggabungkan File");
        }
    }
}
