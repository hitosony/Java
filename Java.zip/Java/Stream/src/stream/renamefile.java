/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stream;

/**
 *
 * @author Anonymous
 */

import java.io.*;

public class renamefile {
    public static void main(String[] args) throws IOException {
        String alamat1;
        String alamat2;
        String folder;
        String nama;
        BufferedReader br = new BufferedReader(new InputStreamReader (System.in));
        System.out.println("Masukkan Alamat File: ");
        alamat1 = br.readLine();
        File f = new File(alamat1);
        System.out.println("Masukkan Nama Pengganti Beserta Alamat File: ");
        alamat2 = br.readLine();
        if(f.renameTo(new File(alamat2))) System.out.println("Hasil: Sukses");
        else System.out.println("Hasil: Gagal");
        System.out.println("Masukkan Nama Folder Baru Beserta Alamat File: ");
        folder = br.readLine();
        File f2 = new File(folder);
        if(f2.mkdirs()) System.out.println("Hasil: Sukses");
        else System.out.println("Hasil: Gagal");
    }
}
