/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stream;

/**
 *
 * @author Anonymous
 */

import java.io.*;

public class IO {
    
    public static void main(String[] args) {

        String c;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader (System.in));
            System.out.println("Masukkan Kata dan akhiri dengan \"exit\": ");
            do {
                c = (String) br.readLine();
                System.out.println("Kata terbaca: " + c);
            } while (!"exit".equals(c));
        } catch (IOException e) {
            System.out.println("Ada error IO");
            System.exit(0);
        }

    }
    
}
