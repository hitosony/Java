/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stream;

/**
 *
 * @author Anonymous
 */
import java.io.*;

public class cekfolder {
    public static void main(String[]args) throws IOException {
        String Direktori = "D:\\";
        String Folder;
        BufferedReader br = new BufferedReader(new InputStreamReader (System.in));
        System.out.println("Masukkan Nama Folder: ");
        Folder = br.readLine();
        File file = new File(Direktori+Folder);
        if(file.exists())
            System.out.println("True !");
        else
            System.out.println("False !");
    }
}