/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stream;

/**
 *
 * @author Anonymous
 */

import java.io.*;

public class copyisifile {
    public static void main(String args[]){
        try{
            FileReader fr=new FileReader("D:/Java/copy.txt");
            BufferedReader br=new BufferedReader(fr);
            FileWriter fw=new FileWriter("D:/Java/paste.txt");
            BufferedWriter bf=new BufferedWriter(fw);
            String line;
            line=br.readLine();
            while(line !=null){
                try{
                bf.write(line,0,line.length());
                bf.newLine();
                line=br.readLine();
                System.out.println("Data Berhasil Di Copy");
            } catch(Exception e){
                System.out.println("Data Gagal Di Copy");
            }      
            }
            br.close();
            bf.close();
        }    catch(Exception e){
            e.printStackTrace();
        }
    }
}
